/**
 * @author Mark老师   享学课堂 https://enjoy.ke.qq.com
 * 往期课程和VIP课程咨询 依娜老师  QQ：2133576719
 * 类说明：本包中的代码演示了：
 * 1、LengthFieldBasedFrame的使用
 * 2、如何和第三方序列化工具，比如MessagePack进行集成
 * 3、如何实现自己的编解码框架
 */
package cn.enjoyedu.nettybasic.serializable.msgpack;