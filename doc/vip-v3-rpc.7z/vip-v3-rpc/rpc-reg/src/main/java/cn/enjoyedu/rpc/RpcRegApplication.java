package cn.enjoyedu.rpc;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RpcRegApplication {

    public static void main(String[] args) {
        SpringApplication.run(RpcRegApplication.class, args);
    }

}
