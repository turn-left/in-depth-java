/**
 * @author Mark老师   享学课堂 https://enjoy.ke.qq.com
 * 往期课程和VIP课程咨询 依娜老师  QQ：2133576719
 * 类说明：Java序列化的缺点，从性能、大小上和我们自定义的序列化机制进行比较
 */
package cn.enjoyedu.nettybasic.serializable.protogenesis;